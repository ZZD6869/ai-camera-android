# AI识物翻译相机（云端编译起步项目）

## 当前版本说明
本项目目前是可继续开发的 Android CameraX 摄像头预览起步版，带 GitHub Actions 云端编译流程。**尚未集成 `ssd_mobilenet_v2_openimage_v4_quant.tflite` 模型及 601 类标签文件，因此当前 APK 还不能真实识别物体、画检测框或翻译标签。** 不要把摄像头预览版误认为完整识别版。

## 用手机云端编译
1. 在 GitHub 新建一个空仓库，例如 `ai-camera-android`。
2. 解压本 ZIP，把里面的文件和文件夹（包括 `.github`）上传到仓库根目录。
3. 打开仓库的 **Actions** 标签页，选择 **Build Android APK**，点击 **Run workflow**；也可以在推送到 `main`/`master` 后自动触发。
4. 构建成功后打开对应 workflow run，在底部 **Artifacts** 下载 `AI-Camera-debug-apk`，解压得到 `app-debug.apk`。
5. 在小米手机上打开 APK 安装。若系统提示，允许浏览器/文件管理器安装未知应用。

## 下一步接入模型
把确认来源与许可的 TFLite 模型放到 `app/src/main/assets/`，同时提供与模型输出顺序严格匹配的标签文件；再实现图像预处理、推理、NMS/框坐标映射和中文标签映射。模型名称本身不足以保证模型输入尺寸、输出张量或标签顺序，集成前必须核验。
