package com.example.aicamera

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** Placeholder overlay. Connect detector output to draw real boxes and localized labels. */
class DetectionOverlay @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00E5FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // No fabricated boxes: draw actual boxes only after a model is integrated.
    }
    fun showDemoBox() { invalidate() }
}
